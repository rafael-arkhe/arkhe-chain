# claims-ledger

Audit what a project promises against what its code and tests actually do, and keep
the answer honest from then on.

Point it at a spec, whitepaper, README, landing page or dashboard. The agent splits the
promises into atomic claims, traces each one to the code and tests that deliver it,
and writes a registry (`claims.json`) in which every claim is **enforced**, **partial**
or **absent**, with the gap spelled out. A bundled checker refuses any claim the
repository cannot back, so the table cannot drift from the code once it is in CI.

## What you get

- **A claims table** (`CLAIMS.md`) with each claim's label, state, evidence and gap.
- **An overclaim review** of UI and docs: constant `PASS`/`VERIFIED` badges, fail-open
  defaults, phantom steps, invented numbers. Each finding is named with one of 8 patterns.
- **A report** in a fixed format: headline findings first, then fixes tied to claim ids.
- **A CI gate** that fails the build when a claim loses its code or tests, when a
  promise in the README is reworded or removed, or when a new one appears with no
  audit. Add `--fail-on-absent` to also block promises that have no code yet.

## Why it is different

- **Fail-closed by construction.** An unknown state is absent; an absent claim cannot
  list evidence; a partial claim must name its gap; evidence must name the claim (or
  an anchored symbol), so deleting the implementation breaks the claim.
- **Promise and delivery are kept apart.** The epistemic label (`PROVEN`, `LEMMA`,
  `PROPOSAL`, `CONJECTURE`) records what the document asserts; the state records
  what the code does. The findings are where the two disagree.
- **Limits on the same page as the promises.** Gaps stay in the table, next to the claim.

## Use

Ask your agent, for example:
- "Check whether our README matches what the code does."
- "Audit the whitepaper claims against the repo."
- "Our dashboard shows VERIFIED everywhere; is any of it real?"
- "Build an honesty table for this project before the launch."

Or invoke it directly with `/claims-ledger`.

The script needs Python 3.8+ and the standard library only. It makes no network
calls, reads files only inside the project root and writes only `CLAIMS.md`.

```bash
python3 scripts/claims_ledger.py check            # refuse unbacked claims, detect a stale table
python3 scripts/claims_ledger.py render           # write CLAIMS.md
python3 scripts/claims_ledger.py scan src docs    # list literal verdicts to review
```

## Contents

```
claims-ledger/
├── SKILL.md                         workflow and rules for the agent
├── README.md
├── scripts/claims_ledger.py         checker, renderer and scanner
├── references/
│   ├── registry-schema.md           claims.json format, state rules, CI snippet
│   ├── epistemic-labels.md          labels and the severity matrix
│   └── overclaim-patterns.md        OC-1 to OC-8
├── examples/
│   ├── demo-project/                tiny repo with claims, code, tests and planted overclaims
│   └── report.md                    the report the skill produces for the demo
└── tests/test_claims_ledger.py      24 tests, one per refusal rule
```

Try it on the demo: `cd examples/demo-project && python3 ../../scripts/claims_ledger.py check`.

## Limits

The skill finds the code and tests behind a claim; it does not prove that the tests
are good tests. "Enforced" means a mechanism and passing tests exist and the agent
judged that they cover the statement. Review the table like any audit.

Works with any agent that loads SKILL.md skills (Claude Code, Codex CLI, Cursor and
others). The method comes from the "prove, do not promise" discipline of the Arkhe
AGI-P2P framework.
