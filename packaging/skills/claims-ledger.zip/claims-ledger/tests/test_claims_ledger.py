#!/usr/bin/env python3
"""Tests for scripts/claims_ledger.py. Run: python3 -m unittest discover -s tests

Every refusal rule has a test that builds a registry breaking only that rule.
Works in a temporary directory; touches nothing else.
"""
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts' / 'claims_ledger.py'
DEMO = Path(__file__).resolve().parents[1] / 'examples' / 'demo-project'
spec = importlib.util.spec_from_file_location('claims_ledger', SCRIPT)
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)


def good():
    return {'id': 'C-01', 'statement': 'It works.', 'state': 'partial', 'mechanism': 'run()',
            'evidence': ['src/a.py'], 'tests': ['tests/t.py'], 'gap': 'edge cases'}


class Audit(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name).resolve()
        (self.root / 'src').mkdir()
        (self.root / 'tests').mkdir()
        (self.root / 'src' / 'a.py').write_text('# claims-ledger: C-01\ndef run(): pass\n')
        (self.root / 'tests' / 't.py').write_text('')

    def tearDown(self):
        self.tmp.cleanup()

    def errors(self, **change):
        item = {**good(), **change}
        item = {k: v for k, v in item.items() if v is not None}
        return ledger.audit(self.root, {'items': [item]})

    def assertRefused(self, fragment, **change):
        errors = self.errors(**change)
        self.assertTrue(any(fragment in e for e in errors), f'{fragment!r} not in {errors}')

    def test_a_backed_claim_passes(self):
        self.assertEqual(self.errors(), [])

    def test_anchor_evidence_passes_without_source_edits(self):
        self.assertEqual(self.errors(evidence=[{'path': 'src/a.py', 'anchor': 'def run'}]), [])

    def test_empty_registry_is_refused(self):
        self.assertEqual(ledger.audit(self.root, {'items': []}), ['registry has no items'])

    def test_bad_and_duplicate_ids(self):
        self.assertRefused('must look like', id='c1')
        errors = ledger.audit(self.root, {'items': [good(), good()]})
        self.assertTrue(any('duplicate' in e for e in errors))

    def test_unknown_state_and_label(self):
        self.assertRefused('state', state='done')
        self.assertRefused('label', label='TRUE')

    def test_non_enforced_needs_a_gap(self):
        self.assertRefused('must name its gap', gap=None)
        self.assertEqual(self.errors(state='enforced', gap=None), [])

    def test_enforced_cannot_keep_a_gap(self):
        self.assertRefused('enforced claim cannot have a gap', state='enforced')

    def test_absent_cannot_carry_evidence(self):
        self.assertRefused('absent claim cannot', state='absent')

    def test_present_claims_need_mechanism_and_evidence(self):
        self.assertRefused('needs mechanism and evidence', mechanism=None)
        self.assertRefused('needs mechanism and evidence', evidence=[])

    def test_code_without_tests_is_partial_not_absent(self):
        self.assertEqual(self.errors(tests=[]), [])
        self.assertRefused('enforced claim needs tests', state='enforced', gap=None, tests=[])

    def test_evidence_must_exist_and_name_the_claim(self):
        self.assertRefused('does not exist', evidence=['src/missing.py'])
        (self.root / 'src' / 'b.py').write_text('def run(): pass\n')
        self.assertRefused('add a trace comment', evidence=['src/b.py'])
        self.assertRefused('anchor', evidence=[{'path': 'src/a.py', 'anchor': 'renamed_fn'}])
        self.assertRefused('shorter than 3', evidence=[{'path': 'src/a.py', 'anchor': 'r'}])

    def test_paths_cannot_leave_the_project(self):
        self.assertRefused('outside the project', evidence=['../secret.txt'])
        self.assertRefused('outside the project', tests=[str(self.root / 'tests' / 't.py')])

    def test_missing_test_file(self):
        self.assertRefused('test tests/none.py does not exist', tests=['tests/none.py'])


class Sources(unittest.TestCase):
    """The promises themselves: quotes must stay in the source, tracked bullets must be covered."""

    README = '# Tool\n\n## Features\n\n- **Fast** sync of files.\n- Works offline.\n\n## Install\n\n- pip install tool\n'

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name).resolve()
        (self.root / 'README.md').write_text(self.README)

    def tearDown(self):
        self.tmp.cleanup()

    def errors(self, quotes, readme=None):
        if readme is not None:
            (self.root / 'README.md').write_text(readme)
        items = [{'id': f'C-0{n}', 'statement': q, 'state': 'absent', 'gap': 'x', 'quote': q} for n, q in enumerate(quotes, 1)]
        return ledger.audit_sources(self.root, {'sources': [{'path': 'README.md', 'section': 'Features'}], 'items': items})

    def test_covered_section_passes_and_ignores_other_sections(self):
        self.assertEqual(self.errors(['Fast sync of files', 'Works offline']), [])

    def test_a_new_bullet_without_a_claim_fails(self):
        errors = self.errors(['Fast sync of files', 'Works offline'],
                             self.README.replace('- Works offline.', '- Works offline.\n- End-to-end encrypted.'))
        self.assertTrue(any('bullet not covered' in e and 'End-to-end' in e for e in errors), errors)

    def test_a_reworded_promise_fails_its_quote(self):
        errors = self.errors(['Fast sync of files', 'Works offline'], self.README.replace('Works offline', 'Works mostly offline'))
        self.assertTrue(any('C-02: quote no longer appears' in e for e in errors), errors)

    def test_missing_section_and_short_quote(self):
        errors = ledger.audit_sources(self.root, {'sources': [{'path': 'README.md', 'section': 'Nope'}], 'items': []})
        self.assertTrue(any("section 'Nope' not found" in e for e in errors))
        self.assertTrue(any('at least 8' in e for e in self.errors(['Fast', 'Works offline'])))

    def test_source_outside_the_project_is_refused(self):
        errors = ledger.audit_sources(self.root, {'sources': [{'path': '../README.md'}], 'items': []})
        self.assertTrue(any('not found in the project' in e for e in errors))

    def test_fail_on_absent_skips_planned_claims(self):
        registry = {'items': [{'id': 'C-01', 'state': 'absent', 'label': 'LEMMA'},
                              {'id': 'C-02', 'state': 'absent', 'label': 'PROPOSAL'},
                              {'id': 'C-03', 'state': 'absent'},
                              {'id': 'C-04', 'state': 'partial', 'label': 'LEMMA'}]}
        self.assertEqual(ledger.absent_facts(registry), ['C-01', 'C-03'])


class Commands(unittest.TestCase):
    def run_cli(self, *args, cwd=DEMO):
        return subprocess.run([sys.executable, str(SCRIPT), *args], cwd=cwd, capture_output=True, text=True)

    def test_demo_registry_checks(self):
        result = self.run_cli('check')
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('OK enforced 1, partial 2, absent 2', result.stdout)

    def test_stale_table_fails_check(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'claims.json').write_text(json.dumps({'items': [{'id': 'C-01', 'statement': 'x', 'state': 'absent', 'gap': 'y'}]}))
            self.assertEqual(self.run_cli('check', cwd=root).returncode, 1)
            self.assertEqual(self.run_cli('render', cwd=root).returncode, 0)
            self.assertEqual(self.run_cli('check', cwd=root).returncode, 0)

    def test_render_refuses_an_unbacked_registry(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'claims.json').write_text(json.dumps({'items': [{'id': 'C-01', 'statement': 'x', 'state': 'enforced'}]}))
            result = self.run_cli('render', cwd=root)
            self.assertEqual(result.returncode, 1)
            self.assertFalse((root / 'CLAIMS.md').exists())

    def test_fail_on_absent_flag_turns_the_demo_red(self):
        result = self.run_cli('check', '--fail-on-absent')
        self.assertEqual(result.returncode, 1)
        self.assertIn('FAIL C-04: stated as fact but absent', result.stdout)

    def test_scan_finds_the_planted_overclaims(self):
        out = self.run_cli('scan', 'src', 'README.md').stdout
        self.assertIn('src/status.js:3', out)
        self.assertIn('README.md:6', out)
        self.assertNotIn('verify.js', out)


if __name__ == '__main__':
    unittest.main()
