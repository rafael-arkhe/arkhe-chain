---
name: claims-ledger
description: Audits what a project promises (spec, whitepaper, README, landing page, dashboard or UI) against what its code and tests actually do, and keeps the result as a machine-checked claims registry with an honesty table and a CI gate. Each claim gets a state (enforced, partial or absent), the files that implement it, the tests that cover it, and the gap that remains. Use when the user asks to check whether docs or a whitepaper match the code, find overclaims, audit "what is actually implemented", build an honesty or capabilities table, review a UI that shows PASS/VERIFIED/secure badges, prepare a due-diligence or launch readiness check, or stop docs drifting from code. Do not use for fact-checking articles against web sources, for testing business rules on a running server, or for general code review with no stated claims to check.
---

# Claims ledger: prove, do not promise

A project's documents and screens make promises. This skill turns each promise into
a registry entry that the repository either backs or does not, and makes the
difference impossible to hide: a checker refuses any claim without code and tests
behind it, and the rendered table prints the limits on the same page as the promises.

The method in one line: **a claim is only as strong as the weakest link between its
words, the code that implements it, and a test that would fail if that code broke.**

## Rules that never bend

1. **Fail closed.** If you cannot find the mechanism, the claim is `absent`. If you
   find part of it, it is `partial`. Uncertain is never `enforced`.
2. **Never edit a claim to fit the code.** Keep the promise as written and record the
   gap. The user decides whether to change the promise or the code.
3. **`enforced` needs passing tests you ran** (or CI output the user shows you). Code
   with no tests, or tests that were not run, is `partial`, with gap "no test" or
   "tests not run". Never mark real code `absent` because tests are missing: that
   erases what exists.
4. **A verdict shown to a user must be computed.** A literal `PASS`, `VERIFIED` or
   "secure" badge with no verifier behind it is an overclaim, even if the feature works.
5. **Steps after a failure are "not evaluated", never "passed".** Apply this to any
   pipeline, checklist or status screen you review.
6. **Every gap is printed.** No claim leaves the table because its state is bad.

Read `references/registry-schema.md` before writing the registry, and
`references/overclaim-patterns.md` before reviewing UI or docs.

## Workflow

### 1. Find the promises

Ask the user which documents are the source of claims if it is not obvious. Otherwise
use, in order: the spec or whitepaper, README and docs, landing or marketing copy,
then UI text and status screens. Note each source's version or date.

### 2. Extract atomic claims

Split each promise into claims that one test could falsify. "Fast, secure and
offline" is three claims. Give each an id (`C-01`, or a scope prefix such as
`API-01`, `UI-03`) and keep the original wording in `statement`.

Record where each promise lives, so the checker notices when the document changes
and not only when the code does: list the document in `sources` (with its section,
for a feature list) and give each claim a `quote`, a verbatim fragment of its line.
Every bullet in a tracked section needs a claim, even an `absent` one.

Give each claim an epistemic `label` from `references/epistemic-labels.md`:
`PROVEN`, `LEMMA`, `PROPOSAL` or `CONJECTURE`. The label is what the document asserts;
the state is what the code delivers. A `PROPOSAL` that is `absent` is honest; a
`PROVEN` claim that is `absent` is the headline finding.

Drop pure opinion ("beautiful", "delightful"). Keep everything a buyer, auditor or
user would rely on.

### 3. Trace each claim to code and tests

For each claim, search the codebase for the mechanism, then for tests that exercise
it. Prefer tests that would fail if the mechanism were removed: negative tests,
tampered inputs, golden vectors with expected rejections. Read the code; a function
name is not evidence.

Set the state with the rules above. For `partial` and `absent`, write a `gap` that a
developer could turn into a ticket: what is missing, not that something is missing.

Link each evidence file to the claim so a rename or deletion breaks it loudly. Two
ways, both checked by the script:
- **Trace comment** (strongest): a line naming the claim id in the file, such as
  `// claims-ledger: C-04`. **Ask before editing source files.**
- **Anchor** (no edits): `{"path": "src/auth.ts", "anchor": "verifySignature"}`, where
  the anchor is the function or symbol that implements the claim. Use this when the
  user does not want source edits.

### 4. Write and check the registry

Write `claims.json` at the project root (format in `references/registry-schema.md`,
worked example in `examples/demo-project/`). Then run:

```bash
python3 scripts/claims_ledger.py check
```

`scripts/` is inside this skill's folder; run it by its path from the project root
(for example `python3 ~/.claude/skills/claims-ledger/scripts/claims_ledger.py check`).
Use `python` on Windows if `python3` is not found. Fix every `FAIL` line by correcting
the registry, never by weakening the checker. When only the table is stale, run
`render` to write `CLAIMS.md`, then `check` again until it prints `OK`.

### 5. Scan for literal verdicts

```bash
python3 scripts/claims_ledger.py scan src docs
```

Pass the UI and docs directories. Each hit is a question, not a finding: open the
line and decide whether the verdict is computed from a real check (fine) or written
as a constant (overclaim). Classify each confirmed overclaim with
`references/overclaim-patterns.md`. A computed verdict is never an overclaim; if its
wording is broader than the check, put it under "Wording notes" instead.

### 6. Report

Use exactly the structure in `examples/report.md`:
1. Verdict line with totals (enforced / partial / absent) and overclaim count.
2. Headline findings: claims labelled `PROVEN` or `LEMMA` that are `absent`, and
   overclaims a user sees, most severe first.
3. The claim table (or a link to `CLAIMS.md` if long).
4. Overclaims with file:line, pattern name and the fix; then "Wording notes" for
   computed verdicts whose wording could be tighter (not counted as overclaims).
5. What was not checked (tests not run, sources not read).
6. Next steps, each tied to a claim id.

State only what the registry supports. Do not call the project "secure",
"verified" or "production ready" in the report.

### 7. Offer the CI gate (optional)

If the user wants drift to break the build, copy the script into the repository and
add its `check` command to CI after the tests (snippet in
`references/registry-schema.md`). Do not edit CI files without asking; a request to
"make CI fail when..." is that permission.

Name the gate's strength in the report. Plain `check` blocks regressions and new or
reworded promises but tolerates the gaps already recorded. If the user asked for CI
to fail whenever a promised feature has no code, that is `check --fail-on-absent`,
and CI will be red until each absent claim is built or relabelled `PROPOSAL`: say so
before enabling it, and let the user choose. Prove the gate by breaking a scratch
copy (delete one implementation file, add one README bullet) and showing both fail.

## Edge cases

- **No tests at all:** every claim with a mechanism is `partial` with gap "no test".
- **Monorepo:** use `scope` to group claims by package; keep one registry at the root.
- **Claims about third parties** ("audited by X", "SOC 2"): `absent` unless the
  report or certificate is in the repository; never infer from a logo.
- **Numbers** (latency, throughput, accuracy): `enforced` only with a benchmark or
  test that asserts the number; otherwise `partial` with gap "number not measured".
- **The user wants a claim marked enforced anyway:** keep the state the evidence
  supports and record their decision in the gap ("owner accepts without test"). The
  checker refuses an enforced claim that still has a gap, so the two cannot coexist.
