# Epistemic labels

The **label** records how strongly a document asserts a claim. The **state** records
what the code delivers. Keep them separate: the interesting findings are where they
disagree.

| Label | The document is saying | Evidence that would justify it |
|---|---|---|
| `PROVEN` | It is established, by proof or exhaustive test | A proof, a formal model, or tests that cover the whole input space |
| `LEMMA` | It holds in this system and is relied on | Implementation plus tests that would fail without it |
| `PROPOSAL` | It is the design intent, not yet built or measured | A design doc; no code is expected yet |
| `CONJECTURE` | It is believed or hypothesised | Nothing yet; stated so it can be tested |
| `REFUTED` | It was claimed and shown false | The failing test or counterexample |

## How to assign a label

Read the sentence as a buyer would. Present tense with no hedge ("encrypts", "detects",
"guarantees") is `LEMMA`, or `PROVEN` if it says "proven" or "guaranteed". Roadmap
words ("will", "planned", "designed to") are `PROPOSAL`. "We believe", "should",
"expected to" are `CONJECTURE`. If the document gives no hint, use `LEMMA`: readers
assume a capability exists when it is described as one.

## Severity of a label and state mismatch

| Label \ State | enforced | partial | absent |
|---|---|---|---|
| `PROVEN` | fine if the proof exists | **high**: claimed proof, partial delivery | **critical** |
| `LEMMA` | fine | medium: name the gap in the docs | **high** |
| `PROPOSAL` | upgrade the docs, it shipped | fine | fine |
| `CONJECTURE` | upgrade the docs | fine | fine |

Report every critical and high cell as a headline finding. A `PROPOSAL` that is
`absent` is honest documentation and is not a finding.

## Limits on the same page

Every document that states a `LEMMA` or `PROVEN` claim should state its known gaps
next to it, not in a separate "limitations" page nobody reads. When you recommend
doc changes, recommend adding the gap beside the claim, not deleting the claim.
