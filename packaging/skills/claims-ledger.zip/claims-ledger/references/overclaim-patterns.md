# Overclaim patterns

An overclaim is any place where a user is shown more certainty than the system
computed. Use these names in the report so findings are comparable across audits.

## OC-1 Constant verdict

A status written as a literal: `<Badge>VERIFIED</Badge>`, `status: "PASS"` in a fixture
that ships, a green check rendered unconditionally.
**Check:** follow the value back. If no branch can produce a failure state, it is OC-1.
**Fix:** derive the verdict from the check's result; render "not checked" when there is none.

## OC-2 Fail-open default

Missing, malformed or unknown input renders as success: `status ?? 'ok'`,
`if (!error) showPass()` where `error` is also undefined on timeout, an unknown enum
value mapped to the green style.
**Fix:** unknown maps to "not verified". Only an explicit success value is success.

## OC-3 Credit after failure

A pipeline stops at step 3 but steps 4 to 9 still show "passed", or a checklist marks
items done because an earlier item failed and the loop exited.
**Fix:** steps after the first failure are "not evaluated".

## OC-4 Phantom step

The UI or docs list a check the code never runs ("hardware attestation verified",
"formal proof checked"). Often copied from a design mockup or a roadmap.
**Check:** find the function that performs the step. No function, no step.
**Fix:** remove the step or show it as "not performed" with the reason.

## OC-5 Invented number

A metric with no measurement behind it: "1,024 peers", "99.98% integrity", "412 ms
finality", "10x faster". Common in dashboards built from mockups.
**Fix:** bind it to a live source or a cited benchmark, or remove it. An empty state
("no peers connected") is honest; a plausible number is not.

## OC-6 Scope creep in a word

"Verified" when only a signature was checked (not the content), "secure" when one
attack was tested, "private" when payloads are encrypted but metadata is not.
**Fix:** say what was checked: "signature valid", "payload encrypted; metadata in clear".

## OC-7 Borrowed authority

Logos, "audited by", "SOC 2", "FIPS" or standard names with no report, certificate or
validated module in the repository. Also implementation candidates presented as
standards ("implements RFC X" when it follows a draft).
**Fix:** link the artefact, or reword to what is true ("follows draft X").

## OC-8 Action without evidence

A button that triggers an outward or irreversible effect (publish, pay, anchor,
deploy, approve) that is enabled while the evidence it depends on is missing.
**Fix:** gate the action on the computed result and show the typed reason it is blocked.
No override prop.

## Not overclaims

- A verdict that a real check computes, even if the word is broader than the check
  (a signature check labelled "VERIFIED"). It can show failure, so it is honest. If
  the wording could be tighter, list it under "Wording notes" in the report, never in
  the overclaim table or the count. OC-6 is for words with no check behind them.
- A literal verdict inside a test fixture or golden vector (it is the expected value).
- A design mockup clearly labelled as illustrative.
- A `PROPOSAL` described as planned.
