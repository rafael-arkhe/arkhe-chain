# Registry schema (`claims.json`)

One JSON object at the project root. `scripts/claims_ledger.py check` enforces every
rule below; a registry that passes cannot contain an unbacked claim.

```json
{
  "title": "Acme Sync claims ledger",
  "source": "README.md (v2.1) and docs/security.md (2026-03)",
  "items": [
    {
      "id": "C-01",
      "scope": "sync",
      "label": "LEMMA",
      "statement": "Files are end-to-end encrypted before upload.",
      "state": "partial",
      "mechanism": "encryptFile() seals each file with XChaCha20-Poly1305 before the upload call",
      "evidence": ["src/crypto.ts", {"path": "src/upload.ts", "anchor": "encryptFile("}],
      "tests": ["tests/crypto.test.ts"],
      "gap": "File names and sizes are uploaded in clear; no test covers the metadata path."
    }
  ]
}
```

## Fields

| Field | Required | Rule |
|---|---|---|
| `title` | no | Heading of the rendered table |
| `source` | no, recommended | Documents and versions the claims were taken from |
| `items[].id` | yes | Unique; uppercase, dash-separated: `C-01`, `API-AUTH-2` |
| `items[].scope` | no | Package, module or screen; groups claims in monorepos |
| `items[].label` | no | Epistemic class the document asserts (see `epistemic-labels.md`) |
| `sources` | no, recommended | `[{"path": "README.md", "section": "Features"}]`: documents whose promises are tracked (see below) |
| `items[].statement` | yes | The promise as the document states it; never reworded to fit the code |
| `items[].quote` | with `sources` | A verbatim fragment (8+ characters) of the source line the claim comes from |
| `items[].state` | yes | `enforced`, `partial` or `absent` |
| `items[].mechanism` | if not absent | What in the code delivers the claim, in one sentence |
| `items[].evidence` | if not absent | Files that implement it; each must name the claim id, or be `{path, anchor}` |
| `items[].tests` | if enforced | Test files that exercise the mechanism; a partial claim may have none if its gap says so |
| `items[].gap` | if not enforced | What is missing, concrete enough to become a ticket |

## State rules

- `enforced`: mechanism and passing tests cover the **whole** statement. No gap needed.
- `partial`: a named mechanism covers part of it, or covers it with no test. Gap is
  mandatory and names what is missing ("no test" counts).
- `absent`: nothing in the repository delivers it. Must have a gap and must **not**
  list mechanism, evidence or tests (a claim cannot be absent and evidenced at once).

All paths are relative to the project root; absolute paths and paths that leave the
root are rejected.

## Evidence links

A plain path passes only if the file contains the claim id, usually as a trace
comment (`// claims-ledger: C-01`). An object `{"path": ..., "anchor": ...}` passes if
the file contains the anchor string (3+ characters; use a function or type name).
Either way, deleting or renaming the implementation fails the check.

## Tracking the source document

Code drift is half the problem; the other half is the promise changing. With
`sources`, `check` also fails when:

- a claim's `quote` is no longer in any source file (someone reworded or deleted the
  promise, so the audit of it is stale);
- a bullet under a tracked `section` has no claim whose quote it contains (someone
  added a promise nobody audited).

Matching ignores Markdown emphasis (`**`, `_`, backticks) and repeated spaces. The
section runs from its heading to the next heading of the same or higher level, so
`## Features` does not pull in `## Install`. Omit `section` to check quotes only.

## CI gate

Fail the build when docs and code drift apart:

```yaml
# GitHub Actions step
- name: Claims ledger
  run: python3 path/to/claims_ledger.py check
```

```bash
# pre-commit or Makefile target
python3 path/to/claims_ledger.py check || exit 1
```

Copy the script into the repository (for example `tools/claims_ledger.py`) so CI does
not depend on a local skills folder.

Two gate strengths. Pick with the user; do not choose for them:

| Command | Fails when | Use when |
|---|---|---|
| `check` | a backed claim loses its code or tests, the table is stale, a promise changes or a new one appears | The team accepts known gaps for now, but wants no new ones |
| `check --fail-on-absent` | all of the above, plus any absent claim stated as fact | Promises without code must block the build (CI goes red until each is built or relabelled `PROPOSAL`) |

`check` does not run the tests; keep the test step before it in CI so a listed test
that fails also fails the build.
