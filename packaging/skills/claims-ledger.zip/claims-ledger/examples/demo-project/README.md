# Notary

Notary signs release files so anyone can check them offline.

- Every release is signed with Ed25519.
- Tampered files are always detected.
- Verification works fully offline.
- Signing keys live in a hardware security module.
- Verifies 10,000 files per second.
