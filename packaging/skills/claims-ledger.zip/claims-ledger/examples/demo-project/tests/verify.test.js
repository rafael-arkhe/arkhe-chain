import assert from 'node:assert/strict';
import { generateKeyPairSync, sign } from 'node:crypto';
import test from 'node:test';
import { digest, verifyRelease } from '../src/verify.js';

const { publicKey, privateKey } = generateKeyPairSync('ed25519');
const file = Buffer.from('release 1.0.0');
const signature = sign(null, Buffer.from(digest(file)), privateKey);

test('a signed release verifies', () => {
  assert.equal(verifyRelease(file, signature, publicKey), true);
});

test('a one-byte change is rejected', () => {
  const tampered = Buffer.from(file);
  tampered[0] ^= 1;
  assert.equal(verifyRelease(tampered, signature, publicKey), false);
});
