// Release verification for Notary. Uses only node:crypto, no network.
// claims-ledger: C-01 C-02 C-03
import { createHash, verify } from 'node:crypto';

export function digest(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}

/** True only when the Ed25519 signature over the file's digest is valid. */
export function verifyRelease(bytes, signature, publicKey) {
  return verify(null, Buffer.from(digest(bytes)), publicKey, signature);
}
