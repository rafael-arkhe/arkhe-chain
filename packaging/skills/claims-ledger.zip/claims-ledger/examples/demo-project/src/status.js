// Status line shown in the CLI after `notary check`.
export function statusLine(file) {
  return `${file}: VERIFIED`;
}
