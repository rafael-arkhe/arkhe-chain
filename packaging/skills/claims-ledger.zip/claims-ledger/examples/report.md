# Claims ledger report: Notary

**Verdict:** 5 claims from README.md: **1 enforced, 2 partial, 2 absent**. 2 overclaims
in user-facing text. `claims_ledger.py check` passes; the table is in `CLAIMS.md`.

## Headline findings

1. **C-02, labelled PROVEN, is only partial.** "Tampered files are always detected"
   rests on one test that flips one byte. Nothing tests a substituted key, and
   `src/status.js:3` prints `VERIFIED` without calling the verifier (OC-1).
2. **C-04 and C-05 are absent but stated as facts.** There is no HSM integration and no
   benchmark behind "10,000 files per second" (OC-5).
3. **C-01 is half built.** The repository verifies signatures but never produces one,
   so "every release is signed" depends on a process outside the code.

## Claims

| ID | Label | State | Claim | Gap |
|---|---|---|---|---|
| C-01 | LEMMA | partial | Every release is signed with Ed25519. | Nothing signs releases or blocks an unsigned one. |
| C-02 | PROVEN | partial | Tampered files are always detected. | One-byte test only; status line bypasses the verifier. |
| C-03 | LEMMA | enforced | Verification works fully offline. | — |
| C-04 | LEMMA | absent | Signing keys live in a hardware security module. | No HSM or PKCS#11 integration. |
| C-05 | LEMMA | absent | Verifies 10,000 files per second. | No benchmark. |

## Overclaims

| Where | Pattern | What the user sees | Fix |
|---|---|---|---|
| `src/status.js:3` | OC-1 Constant verdict | `release.tar: VERIFIED` for every file | Take the result of `verifyRelease()`; print `NOT VERIFIED` on false |
| `README.md:6` | OC-6 Scope creep | "always detected" | "A changed byte is detected (tested); key substitution is not yet tested" |

## Not checked

- Tests were run (`node --test`: 2 passed). No CI history was available.
- Only README.md was used as a source; there are no other docs.

## Next steps

1. C-02: make `statusLine()` take the verification result, and add a wrong-key test.
2. C-01: add a release step that signs and refuses to publish without a signature.
3. C-04, C-05: either build them or move both lines to a "Planned" section (`PROPOSAL`).
4. Add `python3 tools/claims_ledger.py check` to CI so the table cannot drift.
